This is the student distribution for the courseware for 16-362 
Mobile Robot Programming at CMU-RI.

Files and Directories:
----------------------

Raspbot.m implements the main api to the robot

custom_robot_msgs defines custom ROS messages that are not included in the MATLAB ROS toolkit

examples are short example code that illustrates use of the api and the simulator

robot tests is for short tets to make sure your robot is working

sim is the actual implementation of the simulator

utils is a few classes that you may find generally useful. Others that are specifically associated with laboratory execises are also in here.